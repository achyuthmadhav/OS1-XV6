#include "types.h"
#include "stat.h"
#include "user.h"

int main(int argc, char *argv[])
{
   int arg = atoi(argv[1]);
   info(arg);
   exit();
}
