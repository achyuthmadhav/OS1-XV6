#include "types.h"
#include "stat.h"
#include "user.h"
#include "syscall.h" 

int main(int argc, char *argv[])
{
int y;
if(assigntickets(10)==0)
sleep(5);
//assigntickets(atoi(argv[1]));

int i,k;
const int loop=86000;
for(i=0;i<loop;i++){
for(k=0;k<loop;k++){
asm("nop");
asm("nop");
}
}
y=countticks();
printf(1,"Number of ticks for prog3 = %d\n",y);
 exit();
}

