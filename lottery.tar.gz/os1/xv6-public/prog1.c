#include "types.h"
#include "stat.h"
#include "user.h"
#include "syscall.h"

int main(int argc, char *argv[])
{
int y;
//assigntickets(atoi(argv[1]));
if(assigntickets(30)==0)
sleep(5);
const int loop=86000;
int i,k;
for(i=0; i<loop; i++){
     for(k=0; k<loop; k++){
asm("nop");
asm("nop");
}
}
y = countticks();
printf(1," the number of ticks for prog1 = %d\n",y);
exit();
}

