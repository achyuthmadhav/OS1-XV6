#include "types.h"
#include "stat.h"
#include "user.h"
#include "syscall.h" 

int main(int argc, char *argv[])
{
int y;

assigntickets(atoi(argv[1]));
int i,k;
const int loop=43000;

for(i=0;i<loop;i++){
     for(k=0;k<loop;k++){
asm("nop");
asm("nop");
}
}
y=countticks();
printf(1,"Number of ticks for prog2 = %d\n",y);
 exit();
}

