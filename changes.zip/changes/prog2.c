#include "types.h"
#include "stat.h"
#include "user.h"
#include "syscall.h" 

int main(int argc, char *argv[])
{
int x, y;

x=assigntickets(atoi(argv[1]));
int i,j;
const int n=43000;

for(i=0;i<n;i++){
     for(j=0;j<n;j++){
asm("nop");
asm("nop");
}
}
y=countticks();
printf(1,"Number of ticks for prog2 = %d\n",y);
 exit();
}

