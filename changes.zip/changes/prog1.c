#include "types.h"
#include "stat.h"
#include "user.h"
#include "syscall.h"

int main(int argc, char *argv[])
{
int x;
int y;
x = assigntickets(atoi(argv[1]));
const int n=43000;
int i,j;
for(i=0; i<n; i++){
     for(j=0; j<n; j++){
asm("nop");
asm("nop");
}
}
y = countticks();
printf(1," the number of ticks for prog1 = %d\n",y);
exit();
}

